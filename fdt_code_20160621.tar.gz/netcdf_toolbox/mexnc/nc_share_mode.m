function mode = nc_share_mode()
% NC_SHARE_MODE:  returns integer mnemonic for NC_SHARE
%
% USAGE:  mode = nc_share_mode;
mode = 2048;
return


