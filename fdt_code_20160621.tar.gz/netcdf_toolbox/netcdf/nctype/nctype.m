function nctype

% nctype -- Switch to the nctype directory.
%  nctype (no arguments) switches to the directory
%   that contains the nctype definitions.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.

setdef nctype
