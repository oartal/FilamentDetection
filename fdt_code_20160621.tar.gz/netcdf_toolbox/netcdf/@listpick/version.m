function version(self)

% Version of 25-Mar-2003 11:36:42.

helpdlg(help(mfilename), 'listpick')
